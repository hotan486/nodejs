// sunday01ex08_fs_readFile.js

var fs = require('fs');

// 파일을 비동기 IO로 읽어 들인다.
fs.readFile('./package.json', 'utf8', function(err, data) {
    // 읽어들인 데이터를 출력합니다.
    console.log(data);
});