var Calc = require('./node_weekend01_ex12_event_calc');

var calc = new Calc();
calc.emit('stop');

console.log(Calc.title + '에 stop 이벤트 전달함.'); 