// sunday01ex09_fs_writeFile.js

var fs = require('fs');

var msg = 'Hello World';

fs.writeFile('./output.txt', msg, function(err){
    if(err) {
        console.log('Error : ', err);
        return;
    }
    
    console.log('ouput.txt에 파일 쓰기 완료!');
});