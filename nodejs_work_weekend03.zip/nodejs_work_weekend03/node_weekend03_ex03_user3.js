// node_weekend03_ex03_user3.js
// moduel.exports에 객체 추가 - 모듈에서 접근 가능
module.exports = {
    getUser : function() {
        return {id : 'test01', name:'방탄소년단'}
    },
    group : {id : 'group01', name : '친구'}
}