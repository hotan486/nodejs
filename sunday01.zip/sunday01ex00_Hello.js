﻿//sunday01ex00_Hello.js

var names = ["홍길동","김길동","박길동","김길순"];
for(var name of names) {
	console.log(`Hello ${name}`);
}

// CMD 화면에서 파일 실행 : 
// > node Hello.js