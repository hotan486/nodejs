// sunday01ex17_express02.js
var http = require('http');
var express = require('express');
var app = express();
// npm install cors --save
var cors = require('cors');
// cors 미들웨어 적용
app.use(cors());

app.get('/', function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/html;charset=utf8;'});
    res.write('<h2>웹 계산기</h2>');
    res.end();
});

// http://localhost:3000/plus/100/30
// 파라미터는 모두 문자열 타입
app.get('/plus/:a/:b', function(req, res) {
    res.end(JSON.stringify(Number(req.params.a) + Number(req.params.b)));
});

app.get('/minus/:a/:b', function(req, res) {
    res.end(JSON.stringify(Number(req.params.a) - Number(req.params.b)));
});

app.get('/mult/:a/:b', function(req, res) {
    res.end(JSON.stringify(Number(req.params.a) * Number(req.params.b)));
});

app.get('/div/:a/:b', function(req, res) {
    res.end(JSON.stringify(Number(req.params.a) / Number(req.params.b)));
});

var server = http.createServer(app);

server.listen(3000, function () {
    console.log('http://localhost:%d', 3000);
});