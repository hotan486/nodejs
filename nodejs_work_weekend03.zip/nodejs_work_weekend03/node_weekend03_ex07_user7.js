// 사용 패턴 : exports에 속성으로 추가된 함수 객체를 그대로 참조 한 후 호출
exports.printUser = function() {
    console.log('user 이름은 소녀시대입니다.');
}