// sunday01ex01_console.js

/*console.log('Hello world');
console.log("Hello","world");

console.log('숫자 보여주기: %d', 10);
console.log('문자 보여주기: %s', '기생충');

var name = "김길동";
console.log("Name => " + name);
console.log(`성명 => ${name}`);

console.log('JSON 객체 보여주기: ' + {"anme":"조여정"}); // Object라고 표시됨
console.log('JSON 객체 보여주기: %j', {"anme":"조여정"});
console.log('JSON 객체 보여주기: ' + JSON.stringify({"anme":"조여정"}));
console.log('JSON 객체 보여주기: ', {"anme":"조여정"});*/


var result = 0;
console.time('time_check');

for(var i=1; i<10000; i++) {
    result += i;
}

console.timeEnd('time_check');
console.log("result => ", result);

console.log("현재 실행 파일 명 : %s", __filename);
console.log("현재 실행 파일 패스 : %s", __dirname);














