var http = require('http');
var express = require('express');

var app = express();

app.get('/home', function(req, res) {
   res.end('this is home page');
});

app.get('/profile', function(req, res) {
    res.end('htis is profile page');
});

var server = http.createServer(app);

server.listen(3000, function() {
    console.log('http://localhost:%d', 3000);
});