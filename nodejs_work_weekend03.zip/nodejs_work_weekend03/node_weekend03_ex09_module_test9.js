// module.exports에 할당된 new로 생성된 인스턴스 객체를 호출
var user = require('./node_weekend03_ex09_user9').user;

user.printUser();