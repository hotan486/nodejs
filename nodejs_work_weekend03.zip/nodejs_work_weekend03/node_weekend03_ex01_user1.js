// p.284
// node_weekend03_ex01_user1.js

// exports에 속성을 추가하고 함수나 객체를 지정한다.
exports.getUser = function() {
    return {id:'test01', name:'소녀시대'};
}

exports.group = {id:'group01', name:'친구'};