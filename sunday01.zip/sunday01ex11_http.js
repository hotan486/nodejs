// sunday01ex10_fs_pipe.js

var http = require('http');
var fs = require('fs');

var server = http.createServer(function(req, res) {
    // 요청 들어오면 실행 되는 콜백함수.
    console.log("요청 들어 옴...");
    //res.end("<h1>Request ...</h1>");
    
    // 실제 프로젝트에서는 View Engine을 사용합니다.
    var instream = fs.createReadStream('./output.txt');
    instream.pipe(res);
});

// 서버 실행
server.listen(3000, function() {
    console.log("http://localhost:%d", 3000);
});
