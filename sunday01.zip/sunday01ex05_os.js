// sunday01ex05_os.js

// os내장모듈을 불러온다.
var os = require('os');

console.log('os의 호스트 네임: %s', os.hostname());
console.log('시스템 메모리: %d/%d', os.freemem(), os.totalmem());
console.log('시스템의 CPU 정보 : %j', os.cpus());
console.log('네트워크 인터페이스정보', os.networkInterfaces());