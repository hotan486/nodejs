// sunday01ex04_require.js

var calc = require('./sunday01ex03_exports');

console.log('calc.minus(5,3) => ', calc.minus(5, 3));
console.log('calc.plus(5,3) => ', calc.plus(5, 3));