// sunday01ex03_exports.js

var calc = {};

calc.minus = function(a, b) {
    return a - b;
}

// calc 객체를 모듈에 등록한다.
// 모듈은 외부 파일에서 require해서 사용한다.
module.exports = calc;

// 반드시 module.exports에 추가하는것이 안전하다.
module.exports.plus = function(a, b) {
    return a + b;
}