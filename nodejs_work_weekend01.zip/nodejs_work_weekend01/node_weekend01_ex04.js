var calc = require('./node_weekend01_ex03');
//console.log('calc.add(2,3) => ', calc.add(2,3));
console.log('calc.minus(5,3) => ', calc.minus(5,3))