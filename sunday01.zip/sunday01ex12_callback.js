// sunday01ex12_callback.js

// 콜백함수란?
// 자바스크립트는 변수에 함수를 대입할 수 있다.

// 함수 선언방법1
function fn01() {
    console.log('fn01 함수 실행!');
}
// 함수는 호출해야 실행 한다.
//fn01();

// 자동 실행
//(function() {
//    console.log('괄호를 붙이면 실행이구나~~');
//})();

// 함수 선언방법2
//var fn02 = function() {
//    console.log('fn02 함수 실행!');
//}
//fn02();

// 기존 함수를 변수에 담기
// 괄호를 사용하지 않고 이름만 대입.
//var fn03 = fn01;
//fn03();

function fn04(callback) {
    if(callback) {
        callback({name:'홍길동', age:25});
    }
}

//fn04(fn01);

fn04(function( data ) {
    console.log('새로 만들면서 삽입된 함수');
    console.log(data.name, data.age);
});


